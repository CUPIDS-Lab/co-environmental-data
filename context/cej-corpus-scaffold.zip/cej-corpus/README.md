# CEJ Corpus — Colorado Environmental Journalism Corpus pipeline

A reproducible pipeline of Jupyter notebooks that builds a database of Colorado
environmental journalists and their reporting since 2014, documenting whether
each article cites any of the 56 environmental data sources catalogued by the
CU Environmental Data Hub.

- **Design:** see `ARCHITECTURE.md`.
- **Methodology:** see `docs/methodology.qmd` and `docs/codebook.md`.
- **Status:** scaffold. Notebooks and `src/cejcorpus/` are stubs; manual
  touchpoints are listed in `ARCHITECTURE.md` section 13 and `AGENTS.md`.

## Quickstart
```bash
uv sync
cp config.example.yaml config.yaml      # M1: edit non-secret config
cp .env.example .env                     # M1: add secrets
uv run pytest                            # verify the scaffold
# then run notebooks nb-00 -> nb-09 in JupyterLab (pilot on Colorado Sun water first)
```

## Pipeline (stages)
retrieval (`nb-01`,`nb-02`) -> cleanup (`nb-03`) -> alignment (`nb-04`,`nb-05`,
`nb-06`) -> verify (`nb-07`) -> analysis (`nb-08`) -> publish (`nb-09`).

## Lineage
Built in the public-interest data-liberation tradition (Sunlight Foundation,
PDF Liberation Working Group, MuckRock, PUDL, Boulder Public Data). Stores
metadata + excerpts + archived links rather than republishing full article text.
