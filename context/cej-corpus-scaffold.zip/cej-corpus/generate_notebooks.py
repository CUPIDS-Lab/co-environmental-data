#!/usr/bin/env python3
"""Generate the nb-00..nb-09 stub notebooks for the CEJ corpus pipeline.

Each notebook: a markdown header (purpose/inputs/outputs/preconditions/stubs),
a setup cell importing cejcorpus, stage cells with STUB banners where a human
is required, and a closing validation cell. Bodies are intentionally stubs.
"""
import nbformat as nbf
from nbformat.v4 import new_notebook, new_markdown_cell, new_code_cell
from pathlib import Path

NB_DIR = Path(__file__).resolve().parent / "notebooks"
NB_DIR.mkdir(parents=True, exist_ok=True)

SETUP = (
    "import sys; sys.path.insert(0, '../src')\n"
    "from cejcorpus import (config, storage, frame, retrieve, extract,\n"
    "                       dictionary, detect, archive, reliability, provenance)\n"
    "# cfg = config.load(); db = storage.connect_sqlite(cfg); r2 = storage.connect_r2(cfg)\n"
    "# run_id = config.new_run_id()\n"
)

def nb(*cells):
    n = new_notebook()
    n["cells"] = list(cells)
    n["metadata"] = {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python"},
    }
    return n

def md(s): return new_markdown_cell(s)
def code(s): return new_code_cell(s)

notebooks = {}

# ---------------------------------------------------------------- nb-00
notebooks["nb-00-config-and-setup"] = nb(
    md("# nb-00 · Config and setup  \n"
       "**Stage:** setup  \n"
       "**Purpose:** load configuration, open connections, create the schema, mint a `run_id`.  \n"
       "**Inputs:** `config.yaml`, `.env`  \n"
       "**Outputs:** open `db`/`r2` connections, empty documented tables, `run_id`  \n"
       "**Manual stub:** M1 (CONFIG) — secrets and endpoints. See ARCHITECTURE.md §13."),
    code(SETUP),
    md("### M1 · Supply configuration and secrets\n"
       "`# === STUB:MANUAL-CONFIG ===` Copy `config.example.yaml`→`config.yaml` and "
       "`.env.example`→`.env`, then fill in R2, Media Cloud, and LLM endpoint values."),
    code("# === STUB:MANUAL-CONFIG === (M1)\n"
         "cfg = config.load()                 # raises until config.yaml/.env exist\n"
         "config.require(cfg.secrets)         # fails fast naming any missing key\n"
         "db = storage.connect_sqlite(cfg)\n"
         "r2 = storage.connect_r2(cfg)\n"
         "storage.ensure_schema(db)           # applies schema.sql idempotently\n"
         "run_id = config.new_run_id()\n"
         "print('run_id =', run_id)"),
    md("### Smoke tests\nConfirm R2 bucket reachable and (optionally) the LLM endpoint responds."),
    code("# r2.head_bucket(Bucket=cfg.secrets['R2_BUCKET'])\n"
         "# optional: ping LLM_BASE_URL\n"
         "pass"),
)

# ---------------------------------------------------------------- nb-01
notebooks["nb-01-build-frame"] = nb(
    md("# nb-01 · Build the sampling frame  \n"
       "**Stage:** retrieval (frame)  \n"
       "**Purpose:** populate `outlets`, `journalists`, `affiliations`.  \n"
       "**Inputs:** `data/lookups/outlets_seed.csv`, author-archive pages, "
       "`data/lookups/journalists_seed.csv`  \n"
       "**Outputs:** seeded frame tables  \n"
       "**Manual stubs:** M2, M3 (RETRIEVAL) — curated outlet/journalist lists, per-CMS patterns."),
    code(SETUP),
    md("### M2 · Curate outlets, then register\n"
       "`# === STUB:MANUAL-RETRIEVAL ===` Edit `outlets_seed.csv` (Corey Hutchins' "
       "newsletter, SEJ/SPJ rosters) including each outlet's `author_archive_pattern`."),
    code("# === STUB:MANUAL-RETRIEVAL === (M2)\n"
         "n = frame.register_outlets(db, '../data/lookups/outlets_seed.csv', run_id)\n"
         "print('outlets registered:', n)"),
    md("### Discover bylines from author-archive pages"),
    code("# for outlet in db['outlets'].rows:\n"
         "#     people = frame.discover_author_pages(outlet)   # STUB M2\n"
         "#     ... assign_journalist_id, upsert journalists + affiliations\n"
         "pass"),
    md("### M3 · Merge journalist seeds (fellows, freelancers, Substackers)\n"
       "`# === STUB:MANUAL-RETRIEVAL ===` People without author-archive pages: CEJ "
       "Scripps Fellows, freelancers, newsletter authors. Curate `journalists_seed.csv`."),
    code("# === STUB:MANUAL-RETRIEVAL === (M3)\n"
         "# merge ../data/lookups/journalists_seed.csv into journalists\n"
         "pass"),
    md("### Validate\ncoverage_tier is provisional until nb-02 counts qualifying articles."),
    code("# assert db['outlets'].count > 0\npass"),
)

# ---------------------------------------------------------------- nb-02
notebooks["nb-02-retrieve-articles"] = nb(
    md("# nb-02 · Retrieve articles  \n"
       "**Stage:** retrieval  \n"
       "**Purpose:** build `articles` metadata (2014→present) and write raw HTML to R2.  \n"
       "**Inputs:** frame, Media Cloud, GDELT, sitemaps, Wayback, manual library exports  \n"
       "**Outputs:** `articles` rows, raw HTML in R2, provenance  \n"
       "**Manual stubs:** M4 (Media Cloud query), M5 (licensed library exports)."),
    code(SETUP),
    md("### M4 · Configure retrieval and enumerate candidate URLs\n"
       "`# === STUB:MANUAL-CONFIG/RETRIEVAL ===` Set Media Cloud collections/keywords/"
       "date window in `config.yaml`. Sitemaps + Wayback need no per-run config."),
    code("# === STUB:MANUAL-CONFIG/RETRIEVAL === (M4)\n"
         "# urls = set()\n"
         "# for outlet in db['outlets'].rows:\n"
         "#     urls |= set(retrieve.sitemap_urls(outlet))\n"
         "#     urls |= {r['url'] for r in retrieve.media_cloud_search(...)}\n"
         "#     urls |= {r['url'] for r in retrieve.gdelt_search(...)}\n"
         "#     urls |= {r['url'] for r in retrieve.wayback_cdx(outlet['sitemap_url'])}\n"
         "pass"),
    md("### Fetch, store raw HTML to R2, upsert article metadata"),
    code("# for url in sorted(urls):\n"
         "#     html = retrieve.fetch(url)                       # cached, polite\n"
         "#     key  = storage.put_raw_html(r2, url, html)       # immutable original\n"
         "#     storage.upsert(db, 'articles', [{...}], pk='article_id', run_id=run_id)\n"
         "#     provenance.record(db, ...)\n"
         "pass"),
    md("### M5 · Ingest manual library-database exports\n"
       "`# === STUB:MANUAL-RETRIEVAL ===` Nexis Uni / ProQuest / NewsBank forbid "
       "automated download. Export manually into `data/original/library/`; rows are "
       "flagged `links_unavailable=true` (databases strip hyperlinks)."),
    code("# === STUB:MANUAL-RETRIEVAL === (M5)\n"
         "# rows = retrieve.ingest_library_export('../data/original/library/', run_id)\n"
         "pass"),
)

# ---------------------------------------------------------------- nb-03
notebooks["nb-03-extract-and-clean"] = nb(
    md("# nb-03 · Extract and clean  \n"
       "**Stage:** cleanup  \n"
       "**Purpose:** raw HTML → clean text, body-only links, normalized metadata; dedupe.  \n"
       "**Inputs:** raw HTML (R2)  \n"
       "**Outputs:** cleaned `articles`, extracted body links staged for detection  \n"
       "**Manual stub:** none (auto). JS-rendered pages flagged `needs_render` to batch."),
    code(SETUP),
    md("### Extract via trafilatura (fallback chain) + body-only links + dedupe"),
    code("# for art in db['articles'].rows_where('raw_html_key is not null'):\n"
         "#     html = storage.get_raw_html(r2, art['raw_html_key'])\n"
         "#     rec  = extract.article(html)             # text + author/date/section\n"
         "#     links = extract.body_links(html)          # main-content only\n"
         "#     h = extract.dedupe_hash(rec['headline'], rec['date'], rec['author'], rec['text'])\n"
         "#     storage.upsert(db, 'articles', [{...}], pk='article_id', run_id=run_id)\n"
         "pass"),
    md("### Validate (pandera) and resolve syndicated duplicates"),
    code("# schema_articles = config_schema = None  # cejcorpus.schema.pandera_articles()\n"
         "# dedupe on dedupe_hash; keep canonical, flag is_syndicated\n"
         "pass"),
)

# ---------------------------------------------------------------- nb-04
notebooks["nb-04-build-source-dictionary"] = nb(
    md("# nb-04 · Build the source dictionary  \n"
       "**Stage:** alignment  \n"
       "**Purpose:** compile URL/host + keyword matcher from the 56-source catalog.  \n"
       "**Inputs:** `data/lookups/colorado_environmental_data_sources.json`  \n"
       "**Outputs:** `data/lookups/source_dictionary.json`, `data_sources` table  \n"
       "**Manual stub:** M6 (CONFIG) — alias + host/subpath curation."),
    code(SETUP + "import json\n"
         "catalog = json.load(open('../data/lookups/colorado_environmental_data_sources.json'))\n"
         "print('sources in catalog:', catalog.get('source_count'))"),
    md("### M6 · Curate match rules, then build the dictionary\n"
       "`# === STUB:MANUAL-CONFIG ===` Disambiguate shared domains (epa.gov/usgs.gov "
       "subpaths; state.co.us vs colorado.gov; *.hub.arcgis.com). Curate keyword aliases. "
       "**Do not** add the unverified NREL `nlr.gov` host — `nrel.gov` is canonical."),
    code("# === STUB:MANUAL-CONFIG === (M6)\n"
         "# d = dictionary.from_catalog(catalog)\n"
         "# json.dump(d, open('../data/lookups/source_dictionary.json','w'), indent=2)\n"
         "# storage.upsert(db, 'data_sources', [...], pk='source_id', run_id=run_id)\n"
         "pass"),
    md("### Unit-test the matcher\nRun `pytest tests/test_dictionary.py` once `match()` is implemented."),
    code("# from cejcorpus.dictionary import match, canonicalize_host\n"
         "# assert canonicalize_host('https://www.epa.gov/x') == 'epa.gov'\n"
         "pass"),
)

# ---------------------------------------------------------------- nb-05
notebooks["nb-05-detect-citations"] = nb(
    md("# nb-05 · Detect citations  \n"
       "**Stage:** alignment  \n"
       "**Purpose:** produce candidate (article × source) citations via the two-stage detector.  \n"
       "**Inputs:** cleaned articles + body links, `source_dictionary.json`, LLM endpoint  \n"
       "**Outputs:** candidate `citations` (`verification_status='auto'`)  \n"
       "**Manual stub:** M7 (CONFIG) — LLM endpoint + prompt template."),
    code(SETUP + "import json\n"
         "# d = json.load(open('../data/lookups/source_dictionary.json'))"),
    md("### Stage A · Deterministic URL matching (high precision — system of record)"),
    code("# for art in db['articles'].rows:\n"
         "#     hits = detect.url_match(art_body_links, d, run_id)\n"
         "#     storage.upsert(db, 'citations', hits, pk='citation_id', run_id=run_id)\n"
         "pass"),
    md("### Stage B · LLM prose classification (recall) — M7\n"
       "`# === STUB:MANUAL-CONFIG ===` Closed-set over the 56 sources on the Alpine "
       "Ollama endpoint; require a verbatim quote span; reject hallucinations. Output "
       "stays candidate-only until nb-07 clears the precision threshold."),
    code("# === STUB:MANUAL-CONFIG === (M7)\n"
         "# cands = detect.llm_classify(art_text, candidate_sources, endpoint, prompt)\n"
         "# cands = detect.reject_hallucinations(cands, art_text)\n"
         "# storage.upsert(db, 'citations', cands, pk='citation_id', run_id=run_id)\n"
         "pass"),
)

# ---------------------------------------------------------------- nb-06
notebooks["nb-06-archive-cited-links"] = nb(
    md("# nb-06 · Archive cited links  \n"
       "**Stage:** alignment  \n"
       "**Purpose:** make every citation re-verifiable against link rot.  \n"
       "**Inputs:** `citations` with `cited_url`  \n"
       "**Outputs:** `cited_url_archive` + timestamp on citations; snapshots in R2  \n"
       "**Manual stub:** none (auto; politely rate-limited)."),
    code(SETUP),
    md("### Save-Page-Now + CDX nearest snapshot for every cited URL"),
    code("# for c in db['citations'].rows_where('cited_url is not null'):\n"
         "#     snap = archive.save_page_now(c['cited_url'])\n"
         "#     near = archive.cdx_nearest(c['cited_url'], c['article_date'])\n"
         "#     storage.upsert(db, 'citations', [{...}], pk='citation_id', run_id=run_id)\n"
         "pass"),
)

# ---------------------------------------------------------------- nb-07
notebooks["nb-07-verify-and-reliability"] = nb(
    md("# nb-07 · Verify and reliability  \n"
       "**Stage:** verify  \n"
       "**Purpose:** gold standard, double-coding, Krippendorff α, detector precision/recall, adjudication.  \n"
       "**Inputs:** stratified citation sample  \n"
       "**Outputs:** `coding` table, `data/audit/reliability.md`, promoted labels  \n"
       "**Manual stubs:** M8 (coding + gold standard), M9 (adjudication)."),
    code(SETUP),
    md("### Draw a stratified sample (outlet × theme × year) and export a coding worksheet"),
    code("# sample = ...  # stratified draw\n"
         "# export worksheet (CSV) for coders\n"
         "pass"),
    md("### M8 · Human double-coding + gold standard\n"
       "`# === STUB:MANUAL-ANALYSIS ===` Coders independently code presence/type per "
       "`docs/codebook.md`. Ingest results into the `coding` table (round 1 + 2, is_gold)."),
    code("# === STUB:MANUAL-ANALYSIS === (M8)\n"
         "# ingest coded worksheets -> db['coding']\n"
         "pass"),
    md("### Reliability + detector validation (the gate)"),
    code("# alpha = reliability.krippendorff_alpha(list(db['coding'].rows), 'citation_type')\n"
         "# metrics = reliability.precision_recall(auto=list(db['citations'].rows),\n"
         "#                                        gold=list(db['coding'].rows_where('is_gold=1')))\n"
         "# print('alpha=', alpha, 'metrics=', metrics)\n"
         "# GATE: promote LLM labels only if precision >= cfg threshold (0.90)\n"
         "pass"),
    md("### M9 · Adjudicate disagreements; update codebook\n"
       "`# === STUB:MANUAL-ANALYSIS ===` Resolve in consensus; log resolution; "
       "set verification_status='adjudicated'/'human_confirmed'."),
    code("# === STUB:MANUAL-ANALYSIS === (M9)\npass"),
)

# ---------------------------------------------------------------- nb-08
notebooks["nb-08-analyze"] = nb(
    md("# nb-08 · Analyze  \n"
       "**Stage:** analysis  \n"
       "**Purpose:** answer the research questions over the verified corpus.  \n"
       "**Inputs:** full DB (citations × articles × journalists × data_sources)  \n"
       "**Outputs:** figures + tables  \n"
       "**Manual stub:** M10 (ANALYSIS) — research questions and interpretation."),
    code(SETUP + "import pandas as pd, matplotlib.pyplot as plt"),
    md("### Load joined analytic views"),
    code("# joined = pd.read_sql('''SELECT ... FROM citations c\n"
         "#   JOIN articles a USING(article_id)\n"
         "#   JOIN article_authors aa USING(article_id)\n"
         "#   JOIN journalists j USING(journalist_id)\n"
         "#   JOIN data_sources s ON s.source_id=c.source_id''', db.conn)\n"
         "pass"),
    md("### M10 · Research questions\n"
       "`# === STUB:MANUAL-ANALYSIS ===` Scaffolding cuts below; the questions, "
       "breakdowns, and interpretation are the analyst's. Examples: citation frequency "
       "by source / theme / provenance tier / outlet / journalist / year; coverage of "
       "the 56 sources; data-citing vs non-data-citing reporting over time."),
    code("# === STUB:MANUAL-ANALYSIS === (M10)\n"
         "# joined.groupby('theme').size()\n"
         "# joined.groupby(joined['publication_date'].str[:4]).size()\n"
         "pass"),
    md("### Detector performance summary (from nb-07 metrics)"),
    code("# precision/recall by citation_type -> table for the methods section\npass"),
)

# ---------------------------------------------------------------- nb-09
notebooks["nb-09-publish"] = nb(
    md("# nb-09 · Publish  \n"
       "**Stage:** publish  \n"
       "**Purpose:** ship the Datasette interface and the Quarto docs site.  \n"
       "**Inputs:** `corpus.db`, `docs/`  \n"
       "**Outputs:** public Datasette instance, documentation site, tagged release  \n"
       "**Manual stub:** M11 (CONFIG) — deploy target + credentials."),
    code(SETUP),
    md("### Build SQLite indexes + FTS; generate metadata.yaml from the data dictionary"),
    code("# sqlite-utils: create indexes on facetable columns; enable FTS on narrative cols\n"
         "# emit data/processed/metadata.yaml from docs/data-dictionary.md\n"
         "pass"),
    md("### M11 · Deploy\n"
       "`# === STUB:MANUAL-CONFIG ===` Choose target (vercel|cloudrun|fly|local) and "
       "supply credentials, then `datasette publish`. Render Quarto to GitHub Pages."),
    code("# === STUB:MANUAL-CONFIG === (M11)\n"
         "# !datasette publish {cfg.settings['publish']['datasette_target']} data/processed/corpus.db \\\n"
         "#     --metadata data/processed/metadata.yaml\n"
         "# !quarto render docs\n"
         "pass"),
)

for name, n in notebooks.items():
    path = NB_DIR / f"{name}.ipynb"
    with open(path, "w") as f:
        nbf.write(n, f)

print("wrote", len(notebooks), "notebooks:")
for name in notebooks:
    print("  notebooks/" + name + ".ipynb")
