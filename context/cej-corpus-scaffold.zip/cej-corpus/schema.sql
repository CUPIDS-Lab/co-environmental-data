-- Canonical relational schema for the CEJ corpus (mirrors src/cejcorpus/schema.py).
-- Applied idempotently by storage.ensure_schema(). Datasette serves this DB.

CREATE TABLE IF NOT EXISTS outlets (
  outlet_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT,                  -- daily | nonprofit | regional | national | student | newsletter | altweekly
  hq_city TEXT,
  ownership TEXT,
  founded TEXT,
  defunct INTEGER DEFAULT 0,
  last_pub_date TEXT,
  sitemap_url TEXT,
  rss_url TEXT,
  author_archive_pattern TEXT,
  paywall_status TEXT,
  run_id TEXT
);

CREATE TABLE IF NOT EXISTS journalists (
  journalist_id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  name_variants TEXT,
  affiliation_type TEXT,      -- staff|freelance|student|newsletter|fellow|national|wire
  coverage_tier TEXT,         -- dedicated|occasional|one_off
  co_resident INTEGER,
  is_org_byline INTEGER DEFAULT 0,
  muckrack_url TEXT,
  disambiguation_status TEXT, -- confirmed|probable|unresolved
  notes TEXT,
  run_id TEXT
);

CREATE TABLE IF NOT EXISTS affiliations (
  affiliation_id TEXT PRIMARY KEY,
  journalist_id TEXT REFERENCES journalists(journalist_id),
  outlet_id TEXT REFERENCES outlets(outlet_id),
  role TEXT,
  start_date TEXT,
  end_date TEXT,
  run_id TEXT
);

CREATE TABLE IF NOT EXISTS articles (
  article_id TEXT PRIMARY KEY,
  outlet_id TEXT REFERENCES outlets(outlet_id),
  headline TEXT,
  canonical_url TEXT,
  publication_date TEXT,
  section_beat TEXT,
  genre TEXT,                 -- news|investigation|column|explainer|newsletter|multimedia|data-viz
  topic_tags TEXT,
  is_syndicated INTEGER DEFAULT 0,
  is_roundup INTEGER DEFAULT 0,
  co_nexus INTEGER,
  series_id TEXT,
  source_method TEXT,         -- mediacloud|gdelt|sitemap|wayback|library
  links_unavailable INTEGER DEFAULT 0,
  needs_render INTEGER DEFAULT 0,
  retrieved_at TEXT,
  raw_html_key TEXT,          -- R2 object key (immutable original)
  links_json TEXT,            -- extracted body links (R2 key or inline JSON)
  archive_url TEXT,
  archive_timestamp TEXT,
  dedupe_hash TEXT,
  run_id TEXT
);

CREATE TABLE IF NOT EXISTS article_authors (
  article_id TEXT REFERENCES articles(article_id),
  journalist_id TEXT REFERENCES journalists(journalist_id),
  byline_order INTEGER,
  PRIMARY KEY (article_id, journalist_id)
);

-- The 56-source catalog (loaded by nb-04 from the JSON inventory).
CREATE TABLE IF NOT EXISTS data_sources (
  source_id TEXT PRIMARY KEY,
  name TEXT,
  theme TEXT,                 -- water|fire|wind|minerals|pollution|land_use
  provenance_tier TEXT,       -- federal|state|local_regional
  agency TEXT,
  landing_url TEXT,
  doc_url TEXT,
  match_hosts TEXT,           -- JSON array of canonical hostnames
  match_keywords TEXT         -- JSON array of aliases for prose detection
);

-- The heart of the DB: one row per (article x data_source) citation.
CREATE TABLE IF NOT EXISTS citations (
  citation_id TEXT PRIMARY KEY,
  article_id TEXT REFERENCES articles(article_id),
  source_id TEXT REFERENCES data_sources(source_id),
  citation_type TEXT,         -- direct_link_data|embedded_viz|named_attribution|
                              -- agency_mention_ambiguous|foia_records|secondary_citation
  attribution_strength INTEGER,  -- 1..6
  data_origin TEXT,           -- published_portal|primary_records|unclear
  is_secondary INTEGER DEFAULT 0,
  detection_method TEXT,      -- url_match|llm|human
  confidence REAL,
  evidence_quote TEXT,        -- verbatim span (LLM) or matched URL (Stage A)
  cited_url TEXT,
  cited_url_archive TEXT,
  cited_url_archive_ts TEXT,
  verification_status TEXT,   -- auto|human_confirmed|adjudicated
  coder_id TEXT,
  run_id TEXT
);

-- Gold standard + double-coding for reliability and detector validation.
CREATE TABLE IF NOT EXISTS coding (
  coding_id TEXT PRIMARY KEY,
  article_id TEXT REFERENCES articles(article_id),
  source_id TEXT REFERENCES data_sources(source_id),
  coder_id TEXT,
  round INTEGER,              -- 1 = first pass, 2 = double-code
  is_gold INTEGER DEFAULT 0,
  citation_type TEXT,
  notes TEXT,
  run_id TEXT
);
