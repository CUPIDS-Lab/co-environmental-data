# Codebook (living document — version it)

Authoritative prose definitions for every coded field. Each entry: definition,
inclusion/exclusion criteria, >=2 worked examples, edge-case rules.

## citation_type  (see methodology memo section 1.4)
1. direct_link_data — hyperlink resolves to a known data-source host.
2. embedded_viz — embedded chart/map attributed to a catalog source.
3. named_attribution — prose names the agency/dataset, no link.
4. agency_mention_ambiguous — agency named, data-vs-non-data unclear; route to adjudication.
5. foia_records — reporter's own records/FOIA, not a published portal.
6. secondary_citation — cites another outlet that cited the data.

## Inclusion criteria for a journalist  (section 1.1)
Place test AND beat test. Record coverage_tier (dedicated/occasional/one_off)
and affiliation_type. (Fill in worked examples during the pilot.)
