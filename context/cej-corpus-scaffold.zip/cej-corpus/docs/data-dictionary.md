# Data dictionary

One row per column. Generated metadata.yaml (nb-09) is derived from this file.

## citations (the core junction table)
| column | type | values / notes |
|---|---|---|
| citation_id | TEXT PK | surrogate |
| article_id | TEXT FK | -> articles |
| source_id | TEXT FK | -> data_sources (one of the 56) |
| citation_type | TEXT | direct_link_data, embedded_viz, named_attribution, agency_mention_ambiguous, foia_records, secondary_citation |
| attribution_strength | INT | 1 (strongest) .. 6 |
| detection_method | TEXT | url_match, llm, human |
| verification_status | TEXT | auto, human_confirmed, adjudicated |
| cited_url / cited_url_archive | TEXT | original + Wayback snapshot (nb-06) |

(Complete the remaining tables — outlets, journalists, affiliations, articles,
article_authors, data_sources, coding — one row per column. See schema.sql.)
