from cejcorpus import extract

def test_dedupe_hash_is_stable():
    a = extract.dedupe_hash("Headline", "2024-01-01", "Jane Doe", "body text here")
    b = extract.dedupe_hash("Headline", "2024-01-01", "Jane Doe", "body text here")
    assert a == b and len(a) == 64
