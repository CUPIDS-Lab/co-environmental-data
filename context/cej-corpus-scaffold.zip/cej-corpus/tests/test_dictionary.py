"""Matcher unit tests — known-good and known-bad URLs against the dictionary.

These run once dictionary.from_catalog/match are implemented (currently stubs).
They encode the contract: data-portal links match; site-chrome links do not.
"""
import pytest
from cejcorpus import dictionary

GOOD = [
    ("https://waterdata.usgs.gov/co/nwis/uv?site_no=09058000", "water-fed-usgs-nwis"),
    ("https://echo.epa.gov/detailed-facility-report?fid=110000", "pollution-fed-epa-echo"),
    ("https://ecmc.colorado.gov/cogis", "minerals-state-ecmc-cogis"),
]
BAD = [
    "https://coloradosun.com/about/",            # site chrome
    "https://twitter.com/intent/tweet",          # share widget
    "https://nlr.gov/anything",                  # unverified NREL rebrand — must NOT match
]

def test_canonicalize_host_strips_www():
    assert dictionary.canonicalize_host("https://www.epa.gov/x") == "epa.gov"

@pytest.mark.parametrize("url,expected", GOOD)
def test_good_urls_match(url, expected):
    pytest.skip("enable once dictionary.from_catalog/match are implemented")

@pytest.mark.parametrize("url", BAD)
def test_bad_urls_do_not_match(url):
    pytest.skip("enable once dictionary.from_catalog/match are implemented")
