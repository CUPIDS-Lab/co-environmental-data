# AGENTS.md — architecture brief for contributors (and future agents)

Read this before touching code. Full design is in ARCHITECTURE.md.

## What this is
A notebook pipeline (nb-00..nb-09) that builds a journalist -> article ->
data-source-citation corpus for Colorado environmental reporting since 2014.
Notebooks are thin; logic lives in `src/cejcorpus/`. SQLite (`data/processed/
corpus.db`) holds labels; Cloudflare R2 holds evidence (raw HTML, snapshots).

## Conventions worth defending
- Notebooks orchestrate; never put reusable logic in a notebook — put it in the
  package and import it.
- Immutable originals: raw HTML written to R2 once, never edited. Cleaning makes
  new records. Provenance is a sidecar keyed on (article_id, run), not per row.
- Every write stamps `run_id`. Idempotent upserts on stable IDs.
- The 56-source catalog dictionary (Stage A URL match) is the citation system of
  record. The LLM (Stage B) is candidate-only until nb-07 clears the precision
  threshold.
- Archive every cited URL at coding time (nb-06). No exceptions.
- Do NOT add the unverified NREL "nlr.gov" host to the dictionary; nrel.gov is
  canonical until confirmed.

## Stub convention (see ARCHITECTURE.md section 13 for the full register)
- `# === STUB:MANUAL-CONFIG ===`     credentials/endpoints/parameters (M1,M6,M7,M11)
- `# === STUB:MANUAL-RETRIEVAL ===`  curated lists / licensed exports     (M2,M3,M4,M5)
- `# === STUB:MANUAL-ANALYSIS ===`   coding / gold standard / RQs         (M8,M9,M10)
Package functions needing a human raise NotImplementedError pointing to the register.

## How to add an outlet
1. Add a row to `data/lookups/outlets_seed.csv` (M2) with its sitemap + author
   archive pattern.
2. Re-run nb-01 (frame) then nb-02 (retrieve) scoped to that outlet.
3. Re-measure extraction quality on its first batch (CMS varies); fix `extract.py`
   fallbacks if needed.

## How to add a data source
1. Add it to the 56-source catalog JSON with `match_hosts` + `match_keywords`.
2. Re-run nb-04 to rebuild `source_dictionary.json` and the `data_sources` table.
3. Add a matcher unit test (known-good + known-bad URL) under `tests/`.

## Deployment surfaces
- Datasette (data interface) — nb-09 / `datasette publish`.
- Quarto on GitHub Pages (docs/methodology/codebook) — `docs/`.
- R2 + Releases (bulk raw artifacts).
