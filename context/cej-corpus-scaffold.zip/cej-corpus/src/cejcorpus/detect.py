"""Two-stage citation detector.

Stage A: deterministic URL matching (high precision, system of record).
Stage B: LLM prose classification on CU Research Computing / Alpine (Ollama),
closed-set over the 56 sources, verbatim-quote-span required, hallucinations
rejected. Manual touchpoint M7 (LLM endpoint + prompt) — section 13.
"""
from __future__ import annotations


def url_match(article_links: list[str], dictionary: dict, run_id: str) -> list[dict]:
    """Stage A — emit direct_link_data citations for matched body links."""
    raise NotImplementedError("STUB — for each link, dictionary.match(); emit citation rows.")


def llm_classify(article_text: str, candidate_sources: list[dict], endpoint: str, prompt: str) -> list[dict]:
    """Stage B — closed-set classification; each asserted citation needs a quote span.

    # === STUB:MANUAL-CONFIG === (M7)  endpoint + prompt are operator-set/tuned.
    """
    raise NotImplementedError("STUB M7 — call Ollama/OpenAI-compatible endpoint; parse JSON.")


def reject_hallucinations(citations: list[dict], article_text: str) -> list[dict]:
    """Drop any LLM citation whose evidence_quote is not found verbatim in text."""
    return [c for c in citations if c.get("evidence_quote", "") and c["evidence_quote"] in article_text]
