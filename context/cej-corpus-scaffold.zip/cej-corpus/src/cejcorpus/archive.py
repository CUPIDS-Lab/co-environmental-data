"""Link archiving against rot: Wayback Save-Page-Now + CDX nearest snapshot."""
from __future__ import annotations


def save_page_now(url: str) -> str | None:
    """Force a fresh Wayback capture; return the snapshot URL."""
    raise NotImplementedError("STUB — POST web.archive.org/save/<url>; parse Content-Location.")


def cdx_nearest(url: str, when: str) -> dict | None:
    """Find the Wayback snapshot closest to an article's publication date."""
    raise NotImplementedError("STUB — GET cdx/search/cdx?url=...&from=&to=&output=json.")
