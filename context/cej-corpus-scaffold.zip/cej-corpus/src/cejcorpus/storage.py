"""SQLite (sqlite-utils) + Cloudflare R2 (boto3 S3) connections and writes.

SQLite is the system of record for labels; R2 is the system of record for
evidence (raw HTML, archived snapshots). Relational rows never inline blobs;
they reference R2 object keys.
"""
from __future__ import annotations
from pathlib import Path


def connect_sqlite(cfg):
    """Open (creating if needed) data/processed/corpus.db via sqlite-utils."""
    raise NotImplementedError("STUB — sqlite_utils.Database(cfg.db_path).")


def connect_r2(cfg):
    """Return a boto3 S3 client configured for the Cloudflare R2 endpoint.

    # === STUB:MANUAL-CONFIG === (M1)  endpoint_url + R2 creds come from .env.
    """
    raise NotImplementedError("STUB — boto3 client(endpoint_url=R2..., keys from .env).")


def ensure_schema(db, ddl_path: str | Path = "schema.sql") -> None:
    """Apply schema.sql idempotently (CREATE TABLE IF NOT EXISTS ...)."""
    raise NotImplementedError("STUB — execute schema.sql against db.")


def put_raw_html(r2, url: str, html: str) -> str:
    """Write raw HTML to R2 once (immutable); return the object key (raw_html_key)."""
    raise NotImplementedError("STUB — key = sha/url-derived; r2.put_object(...). Return key.")


def get_raw_html(r2, key: str) -> str:
    """Fetch raw HTML back from R2 for re-extraction."""
    raise NotImplementedError("STUB — r2.get_object(Bucket, Key=key).")


def upsert(db, table: str, rows: list[dict], pk: str, run_id: str) -> int:
    """Idempotent upsert; stamps run_id on every row. Returns count written."""
    raise NotImplementedError("STUB — db[table].upsert_all(rows, pk=pk).")
