"""Article extraction: main text, body-only hyperlinks, normalized metadata,
dedupe. Fallback chain: trafilatura -> readability-lxml -> newspaper ->
flag needs_render for Playwright.
"""
from __future__ import annotations
import hashlib


def article(html: str) -> dict:
    """Extract text + metadata (author/date/title/section) from raw HTML."""
    raise NotImplementedError("STUB — trafilatura.extract(...) with JSON-LD/meta; fallback chain.")


def body_links(html: str) -> list[str]:
    """Hyperlinks from the main-content node only (drop header/footer/aside)."""
    raise NotImplementedError("STUB — parse main-content DOM; return outbound hrefs.")


def dedupe_hash(headline: str, date: str, author: str, text: str) -> str:
    """Stable hash for syndication/duplicate detection."""
    key = f"{(headline or '').strip().lower()}|{date}|{(author or '').strip().lower()}|{(text or '')[:200]}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()
