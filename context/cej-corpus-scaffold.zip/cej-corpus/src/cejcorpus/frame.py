"""Sampling-frame registry: outlets, journalists, affiliations.

Manual touchpoints M2/M3 (ARCHITECTURE.md section 13): the outlet list,
per-CMS author-archive URL patterns, and journalist seeds are hand-curated.
"""
from __future__ import annotations


def register_outlets(db, seed_csv: str, run_id: str) -> int:
    """Load the hand-curated outlets_seed.csv into the outlets table.

    # === STUB:MANUAL-RETRIEVAL === (M2)
    """
    raise NotImplementedError("STUB M2 — read outlets_seed.csv -> upsert outlets.")


def discover_author_pages(outlet: dict) -> list[dict]:
    """Enumerate bylines from an outlet's author-archive pages.

    # === STUB:MANUAL-RETRIEVAL === (M2)  author_archive_pattern is per-outlet.
    """
    raise NotImplementedError("STUB M2 — crawl outlet['author_archive_pattern'].")


def assign_journalist_id(name: str, outlet_id: str, active_dates, cobylines) -> str:
    """Deterministic, disambiguated journalist_id (never merge on name alone)."""
    raise NotImplementedError("STUB — composite-key disambiguation -> stable id.")
