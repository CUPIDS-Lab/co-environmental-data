"""Canonical table/column definitions and pandera contracts.

The SQL DDL lives alongside in schema.sql (applied by storage.ensure_schema).
This module is the Python-side source of truth + validation boundary.
"""
from __future__ import annotations

TABLES = [
    "outlets", "journalists", "affiliations", "articles",
    "article_authors", "data_sources", "citations", "coding",
]

# Enums referenced by the codebook (docs/codebook.md is authoritative prose).
CITATION_TYPES = [
    "direct_link_data", "embedded_viz", "named_attribution",
    "agency_mention_ambiguous", "foia_records", "secondary_citation",
]
AFFILIATION_TYPES = ["staff", "freelance", "student", "newsletter", "fellow", "national", "wire"]
COVERAGE_TIERS = ["dedicated", "occasional", "one_off"]
VERIFICATION_STATUS = ["auto", "human_confirmed", "adjudicated"]
DETECTION_METHODS = ["url_match", "llm", "human"]


def pandera_articles():
    """Return a pandera DataFrameSchema for the articles boundary.

    # === STUB ===  Define columns/dtypes/nullability; used at the end of nb-03.
    """
    raise NotImplementedError("STUB — define pandera schema for articles.")


def pandera_citations():
    """Return a pandera DataFrameSchema for the citations boundary (end of nb-05/07)."""
    raise NotImplementedError("STUB — define pandera schema for citations.")
