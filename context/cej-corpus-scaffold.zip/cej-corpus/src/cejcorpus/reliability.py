"""Inter-coder agreement and detector performance metrics.

nb-07 gate: promote LLM labels only when precision clears the pre-registered
threshold; otherwise keep them as human-review candidates.
"""
from __future__ import annotations


def krippendorff_alpha(coding_rows: list[dict], field: str = "citation_type") -> float:
    """Chance-corrected agreement on a nominal field (target >= 0.80)."""
    raise NotImplementedError("STUB — reshape to reliability matrix; krippendorff.alpha(...).")


def precision_recall(auto: list[dict], gold: list[dict]) -> dict:
    """Precision/recall/F1 of the detector vs the hand-coded gold standard,
    overall and per citation_type."""
    raise NotImplementedError("STUB — align (article_id, source_id); compute metrics.")
