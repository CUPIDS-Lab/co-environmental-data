"""Run manifest + per-extract provenance (sidecar, keyed on article/run)."""
from __future__ import annotations


def record(db, article_id: str, source_method: str, tool: str, tool_version: str,
           content_sha256: str, run_id: str) -> None:
    """Append one provenance row per extract."""
    raise NotImplementedError("STUB — insert into provenance sidecar table.")


def manifest(path: str = "data/original/manifest.json") -> dict:
    """Read/write the hash manifest that keeps originals immutable."""
    raise NotImplementedError("STUB — load/save JSON {raw_html_key: sha256}.")
