"""cejcorpus — machinery for the Colorado Environmental Journalism Corpus pipeline.

Thin notebooks import this package; all reusable logic lives here so it is
testable with pytest and reusable across the nb-00..nb-09 pipeline.

Stub status: function bodies that require a credential, a manual list, or a
human decision raise NotImplementedError and point to ARCHITECTURE.md section 13.
"""
__version__ = "0.1.0-scaffold"
