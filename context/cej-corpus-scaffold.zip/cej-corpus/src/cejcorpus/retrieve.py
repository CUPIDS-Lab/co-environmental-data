"""Retrieval clients: Media Cloud, GDELT, sitemaps (trafilatura), Wayback CDX,
plus manual library-database export ingestion.

Manual touchpoints M4 (Media Cloud query params) and M5 (licensed library
exports forbid automation) — see ARCHITECTURE.md section 13.
"""
from __future__ import annotations


def media_cloud_search(api_key: str, collection_ids, start, end, query: str) -> list[dict]:
    """Query Media Cloud for story metadata (url, title, date, domain).

    # === STUB:MANUAL-CONFIG/RETRIEVAL === (M4)  collection_ids + query per run.
    """
    raise NotImplementedError("STUB M4 — mediacloud.api.SearchApi(...).story_list(...).")


def gdelt_search(domain: str, start, end, keywords: str) -> list[dict]:
    """GDELT DOC 2.0 article search (note: officially ~last 3 months)."""
    raise NotImplementedError("STUB — gdeltdoc.GdeltDoc().article_search(filters).")


def sitemap_urls(outlet: dict) -> list[str]:
    """Enumerate all article URLs from an outlet sitemap via trafilatura."""
    raise NotImplementedError("STUB — trafilatura.sitemaps.sitemap_search(outlet['sitemap_url']).")


def wayback_cdx(domain_or_url: str, frm=None, to=None) -> list[dict]:
    """Query the Wayback CDX API for captured URLs / snapshots (defunct + dead links)."""
    raise NotImplementedError("STUB — GET web.archive.org/cdx/search/cdx?url=...&output=json.")


def fetch(url: str):
    """Polite, cached fetch (requests-cache + rate limit + descriptive UA)."""
    raise NotImplementedError("STUB — requests_cache session; throttle; return html.")


def ingest_library_export(path: str, run_id: str) -> list[dict]:
    """Ingest a manual Nexis Uni / ProQuest / NewsBank export.

    # === STUB:MANUAL-RETRIEVAL === (M5)
    Flags rows links_unavailable=true (databases strip hyperlinks).
    """
    raise NotImplementedError("STUB M5 — parse export in data/original/library/.")
