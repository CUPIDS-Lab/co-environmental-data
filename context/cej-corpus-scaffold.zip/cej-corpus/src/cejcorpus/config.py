"""Load configuration and secrets; resolve paths; mint run IDs.

Manual touchpoint M1 (ARCHITECTURE.md section 13): the operator supplies
secrets in .env and non-secret config in config.yaml before nb-00 runs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import datetime as _dt
import uuid

REQUIRED_ENV = [
    "R2_ACCOUNT_ID", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY", "R2_BUCKET",
    "MEDIACLOUD_API_KEY", "LLM_BASE_URL",
]

@dataclass
class Config:
    root: Path = field(default_factory=lambda: Path(__file__).resolve().parents[2])
    settings: dict = field(default_factory=dict)   # parsed config.yaml
    secrets: dict = field(default_factory=dict)    # parsed .env

    @property
    def db_path(self) -> Path:
        return self.root / "data" / "processed" / "corpus.db"

    @property
    def lookups(self) -> Path:
        return self.root / "data" / "lookups"


def load(config_path: str | Path = "config.yaml", env_path: str | Path = ".env") -> Config:
    """Read config.yaml + .env, validate required keys, return a Config.

    # === STUB:MANUAL-CONFIG ===  (M1)
    Implementation: parse YAML (pyyaml) and .env (python-dotenv), then call
    require(). Raises if config.yaml / .env are absent or incomplete.
    """
    raise NotImplementedError(
        "STUB M1 — copy config.example.yaml->config.yaml and .env.example->.env, "
        "then implement YAML/.env parsing. See ARCHITECTURE.md section 9/13."
    )


def require(secrets: dict, keys: list[str] = REQUIRED_ENV) -> None:
    """Fail fast with a clear message naming any missing secret."""
    missing = [k for k in keys if not secrets.get(k)]
    if missing:
        raise RuntimeError(f"Missing required secrets: {', '.join(missing)} (M1).")


def new_run_id() -> str:
    """Stable, sortable run identifier stamped on every row a notebook writes."""
    ts = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"run-{ts}-{uuid.uuid4().hex[:8]}"
