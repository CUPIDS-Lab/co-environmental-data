"""Build the URL/domain + keyword matcher from the 56-source catalog.

Manual touchpoint M6 (ARCHITECTURE.md section 13): alias curation and
host/subpath disambiguation. Do NOT add the unverified NREL 'nlr.gov' host.
"""
from __future__ import annotations
from urllib.parse import urlparse


def canonicalize_host(url: str) -> str:
    """Lowercase host, strip leading www. for matching."""
    host = (urlparse(url).hostname or "").lower()
    return host[4:] if host.startswith("www.") else host


def from_catalog(catalog: dict) -> dict:
    """Explode the 56-source catalog into host rules + keyword aliases.

    # === STUB:MANUAL-CONFIG === (M6)
    Produces {source_id: {hosts:[...], host_subpaths:[...], keywords:[...]}}.
    """
    raise NotImplementedError("STUB M6 — derive match rules from source['links']/['match_*'].")


def match(url: str, dictionary: dict) -> str | None:
    """Return source_id if url matches a host (or host+subpath) rule, else None."""
    raise NotImplementedError("STUB — host match, then host+subpath for shared domains.")
